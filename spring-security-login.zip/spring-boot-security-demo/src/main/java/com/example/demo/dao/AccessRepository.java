package com.example.demo.dao;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.domain.entity.Access;

@Repository
public interface AccessRepository extends JpaRepository<Access, Long> {
	@Query(value = "select * from access \n"
			+ "where role_id in (\n"
			+ "select role_id from user_role where user_id = \n"
			+ "(select id from user where username = :userName))", nativeQuery= true)
	List<Access> findAccessByUserName(String userName);
	
	// 業務流串接
	List<Access> findByRoleIdIn(Collection<? extends Integer> roleId);
}
