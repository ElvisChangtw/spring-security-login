package com.example.demo.util;

import java.util.Collection;
import java.util.List;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import com.example.demo.domain.entity.AppUser;

public class UserAuthorityUtils {
	private static final List<GrantedAuthority> ADMIN_ROLES = AuthorityUtils
			.createAuthorityList("ROLE_ADMIN", "ROLE_USER", "ROLE_STAFF");
			//利用Spring提供的AuthorityUtils中createAuthorityList將該群組加入相關roles
			//以便用一個List變數就儲存所有roles
	
	private static final List<GrantedAuthority> STAFF_ROLES = AuthorityUtils
			.createAuthorityList("ROLE_STAFF", "ROLE_USER");
	
	private static final List<GrantedAuthority> USER_ROLES = AuthorityUtils
			.createAuthorityList("ROLE_USER");
	

	public static Collection<? extends GrantedAuthority> createAuthorities(
			AppUser appUser) {
		String username = appUser.getUsername();
		if (username.contains("admin")) { //帳號中含有admin，即有管理者之role
			return ADMIN_ROLES;
		} else if(username.contains("staff")) {
			return STAFF_ROLES;
		}
		return USER_ROLES; //否則則為一般使用者
	}
}
