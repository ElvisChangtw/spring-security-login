package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.dao.AppUserRepository;
import com.example.demo.dao.RoleRepository;
import com.example.demo.domain.entity.Access;
import com.example.demo.domain.entity.AppUser;
import com.example.demo.domain.entity.Role;
import com.example.demo.domain.entity.UserRole;
@Service
public class AppUserDetailsService implements UserDetailsService {
	private final static Logger logger = LoggerFactory.getLogger(AppUserDetailsService.class);
	@Autowired
    private AppUserRepository appUserRepository;
	@Autowired
	private RoleRepository roleRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	final String rolePrefix= "ROLE_";
	    AppUser user=appUserRepository.findByUsername(username);
        if(user==null){
            throw new UsernameNotFoundException("Invalid username/password");
        }
//        // 用集合及一個util class來取得user的擁有的role
//        Collection<? extends GrantedAuthority> authorities= 
//                UserAuthorityUtils.createAuthorities(user);
        
        List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
        
        for (UserRole autho : user.getAuthorities()) {
        	String authorityName = rolePrefix + autho.getRoleName();
        	System.out.println(authorityName);
        	grantedAuthorities.add(new SimpleGrantedAuthority(authorityName));
        }
        
        //UserAuthorityUtils是helper class
//        return new User(user.getUsername(), user.getPassword(), authorities); 
        
        return new User(user.getUsername(), user.getPassword(), grantedAuthorities); 
        //這邊的User是指org.springframework.security.core.userdetails.User
        //是UserDetails介面的實作，儲存使用者名稱、密碼及擁有權限
	}
	
	// 取得現在登入的user
	public User getCurrentUser() { //取得已登入使用者物件
		SecurityContext context=SecurityContextHolder.getContext(); //從ContextHolder中取得SecurityContext物件
		Authentication auth=context.getAuthentication(); //從SecurityContext物件取得Authentication物件
		//檢查是否有使用者登入
		if(auth== null){
			return null;
		} else if (!(auth.getPrincipal() instanceof User)) {
			return null;
		}
		
		User user = (User) auth.getPrincipal(); 
		// principal: 認証成功前存放 "用戶登入id"，認証成功後存放 "用戶對應的 UserDetails"
		logger.info("test2");
		return user; 
	}
	// 取得現在登入的user可訪問的url(resolve前)
	public Set<String> getAccessibleUrls(User user) {
		Set<String> urls = new HashSet<String>();
		for(GrantedAuthority authority : user.getAuthorities()) {
			String authorityName = authority.getAuthority();
			String roleName = authorityName.replace("ROLE_", ""); // 把authority map成role形式
			
			Role role = roleRepository.findByRole(roleName);
			// 建立Role物件, 透過一對多關係找到對應可存取的urls
			for (Access access : role.getAccesses()) {
				urls.add(access.getUrl());
//				urls.add(access);
			}
		}
		return urls;
	}
	
	
//	@PostConstruct
//	public void createMockData() {
//		// 塞假資料
//		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//		AppUser user1 = AppUser.builder()
//				.username("user")
//				.password(passwordEncoder.encode("user"))
//				.enabled(true)
//				.firstName("user")
//				.lastName("1")
//				.build()
//				
//				, user2= 
//				AppUser.builder()
//				.username("admin")
//				.password(passwordEncoder.encode("admin"))
//				.enabled(true)
//				.firstName("admin")
//				.lastName("2")
//				.build()
//
//				, user3= 
//				AppUser.builder()
//				.username("staff")
//				.password(passwordEncoder.encode("staff"))
//				.enabled(true)
//				.firstName("staff")
//				.lastName("3")
//				.build();
//		appUserRepository.save(user1);
//		appUserRepository.save(user2);
//		appUserRepository.save(user3);
//	}
	
	@PostFilter("hasRole('ADMIN')")
//	@PostFilter("filterObject.getusername() == authentication.principal.username")
	// @PostFilter 可以攔截執行該Method之後所回傳內容(必須為Collection集合)，並賦予權限或篩選特定條件。
	public List<AppUser> findAllUsers(){
		return appUserRepository.findAll();
	}
	
	public void printAuthority() {
		System.out.println("==========print authority==========");
		User user = getCurrentUser();
		System.out.println("user name : " + user.getUsername());
		
		System.out.println("user authority");
		System.out.println(user.getAuthorities());
		
		System.out.println("accessible urls by this user");
		Set<String> urls = getAccessibleUrls(user);
		for( String url : urls) 
			System.out.println("----------" + url + "----------");
		
		System.out.println("==========print authority==========");
	}
	
}
