package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.RoleRepository;
import com.example.demo.domain.entity.Role;

@Service
public class RoleService {
	@Autowired
	RoleRepository roleRepository;
	
	
	public List<Role> findAllRoles(){
		return roleRepository.findAll();
	}
	
	public Role findRoleById(int id) {
		return roleRepository.findById(id);
	}
	
	public Role findByRoleName(String name) {
		return roleRepository.findByRole(name);
	}
	
}
