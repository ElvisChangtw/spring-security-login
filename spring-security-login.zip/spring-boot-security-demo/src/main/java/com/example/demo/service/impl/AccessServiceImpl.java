package com.example.demo.service.impl;

import java.util.Collection;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.AccessRepository;
import com.example.demo.domain.entity.Access;
import com.example.demo.service.interfaces.AccessService;

@Service
@Transactional
public class AccessServiceImpl implements AccessService{
	@Autowired
	AccessRepository accessRepository;
	
	@Override
	public List<Access> findAccessByUserName(String userName) {
		return accessRepository.findAccessByUserName(userName);
	}
	
	@Override
	public List<Access> findByRoleIdIn(Collection<? extends Integer> roleId){
		return accessRepository.findByRoleIdIn(roleId);
	}
}
