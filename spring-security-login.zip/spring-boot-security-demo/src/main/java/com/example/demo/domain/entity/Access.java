package com.example.demo.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name="access")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Access {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int id;
	@Column
	private String url;

	@JoinColumn(name = "roleId")
    @ManyToOne
    private Role role;

	@Override
	public String toString() {
		return "Access [id=" + id + ", url=" + url + "]";
	}
	
	
	
}
