package com.example.demo.controller;

import java.util.List;
import java.util.Set;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.domain.entity.AppUser;
import com.example.demo.service.AppUserDetailsService;

@Controller
public class DemoController {
	@Autowired
	AppUserDetailsService appUserDetailsService;

	@GetMapping("/")
	public String slash() {
		return "home";
	}

	@RequestMapping("/home")
	public String home() {

		return "home";
	}

	@RequestMapping("/home2")
	public String home2(@ModelAttribute("currentUser") User user, Model model) {
		model.addAttribute("urls", appUserDetailsService.getAccessibleUrls(user));
		return "home2";
	}

	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	@RequestMapping("/public")
	public String publicPage() {
		return "public";
	}

	@RequestMapping("/accessDenied")
	public String accessDenied() {
		return "accessDenied";
	}

//	@RolesAllowed({"ADMIN"})
//	@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping("/admin")
	public String admin() {
		return "onlyforadmin";
	}

	@RolesAllowed({ "ADMIN", "USER", "STAFF" })
	@RequestMapping("/hello")
	public String hello() {
		return "hello";
	}

	@RolesAllowed({ "ADMIN", "STAFF" })
	@RequestMapping("/staff")
	public String staff() {
		return "staff";
	}

	@RolesAllowed({ "USER" })
	@RequestMapping("/list")
//	@PostFilter("hasRole('ADMIN')")
	public String listUsers(Model model) {
		List<AppUser> users = appUserDetailsService.findAllUsers();
		model.addAttribute("list", users);
		return "listUsers";
	}

	@ModelAttribute("currentUser")
	public User getUser() {
		return appUserDetailsService.getCurrentUser();
	}

}
