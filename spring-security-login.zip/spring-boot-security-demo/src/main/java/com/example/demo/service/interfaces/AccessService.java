package com.example.demo.service.interfaces;

import java.util.Collection;
import java.util.List;

import com.example.demo.domain.entity.Access;

public interface AccessService {

	List<Access> findByRoleIdIn(Collection<? extends Integer> roleId);
	List<Access> findAccessByUserName(String userName);

}
