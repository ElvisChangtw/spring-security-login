package com.example.demo.domain.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="user")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AppUser {
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(length=50)
	private String username;
	@Column(length=50)
	private String password;
	@Column(length=50)
	private boolean enabled;
	@Column(length=20)
	private String firstName;
	@Column(length=20)
	private String lastName;
	
	@OneToMany(mappedBy = "appUser", fetch = FetchType.EAGER)
	// mappedBy為entity 名稱
    private List<UserRole> authorities;
}
