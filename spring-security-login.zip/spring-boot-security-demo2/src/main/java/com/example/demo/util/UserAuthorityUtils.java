package com.example.demo.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.example.demo.dao.AppUserRepository;
import com.example.demo.domain.entity.AppUser;

public class UserAuthorityUtils {
	@Autowired
	AppUserRepository appUserRepository;
	
	// 塞三筆假user資料進db
	public void createMockData() {
		// 塞假資料進DB
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		AppUser user1 = AppUser.builder()
				.username("user")
				.password(passwordEncoder.encode("user"))
				.enabled(true)
				.firstName("user")
				.lastName("1")
				.build()
				
				, user2= 
				AppUser.builder()
				.username("admin")
				.password(passwordEncoder.encode("admin"))
				.enabled(true)
				.firstName("admin")
				.lastName("2")
				.build()

				, user3= 
				AppUser.builder()
				.username("staff")
				.password(passwordEncoder.encode("staff"))
				.enabled(true)
				.firstName("staff")
				.lastName("3")
				.build();
		appUserRepository.save(user1);
		appUserRepository.save(user2);
		appUserRepository.save(user3);
	}
}
